import mysql.connector

# database.py의 save_order_to_db 함수 정의를 수정
def save_order_to_db(table_number, item, quantity, price):
    conn = None
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="pc_user",
            password="wns032715!",
            database="pc_db"
        )
        cursor = conn.cursor()
        
        # price를 포함해 전달된 인자대로 쿼리를 실행
        order_details = (table_number, item, quantity, price)
        cursor.execute(
            "INSERT INTO orders (table_id, menu_item, quantity, price) VALUES (%s, %s, %s, %s)",
            order_details
        )
        conn.commit()
    except mysql.connector.Error as err:
        print(f"Database Error: {err}")
    finally:
        if conn and conn.is_connected():
            conn.close()
