import sys
import json
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import PoseStamped
from nav2_msgs.srv import SetInitialPose
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QGridLayout, QFrame, QPushButton
)
from PyQt5.QtCore import Qt, QTimer, QThread, QDateTime
from PyQt5.QtGui import QPixmap

# TurtleBot3 좌표 정의
TABLE_COORDINATES = {
    1: (0.887, 0.865, 0.0),
    2: (0.826, -0.252, 0.0),
    3: (0.933, -1.264, 0.0),
    4: (-0.2641, 1.071, 0.0),
    5: (-0.264, 0.004, 0.0),
    6: (-0.264, -1.085, 0.0),
    7: (-1.515, 0.957, 0.0),
    8: (-1.331, -0.222, 0.0),
    9: (-1.163, -1.325, 0.0),
    "kitchen": (-1.790, -0.865, 0.0)  # 주방 좌표
}


class KitchenSubscriber(Node):
    def __init__(self):
        super().__init__('kitchen_subscriber')
        self.subscription = self.create_subscription(
            String,
            'order_topic',
            self.listener_callback,
            10
        )
        self.publisher = self.create_publisher(PoseStamped, '/goal_pose', 10)  # TurtleBot3로 이동 명령 퍼블리셔
        self.orders = {}

        # 초기 위치 설정 서비스 클라이언트 생성
        self.initial_pose_client = self.create_client(SetInitialPose, '/set_initial_pose')
        self.action_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        while not self.initial_pose_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /set_initial_pose service...')
        
        # 프로그램 시작 시 초기 위치를 주방으로 설정
        self.set_initial_pose_to_kitchen()

    def listener_callback(self, msg):
        data = json.loads(msg.data)
        table_number = data['table_number']
        cart_items = data['cart_items']

        self.get_logger().info(f"Received order: {data}")

        # Update orders for the corresponding table
        if table_number not in self.orders:
            self.orders[table_number] = {}
        for item, (price, quantity) in cart_items.items():
            if item in self.orders[table_number]:
                self.orders[table_number][item] += quantity
            else:
                self.orders[table_number][item] = quantity

    def set_initial_pose_to_kitchen(self):
        """TurtleBot3 초기 위치를 주방으로 설정"""
        req = SetInitialPose.Request()
        req.pose.header.frame_id = 'map'
        req.pose.pose.pose.position.x = TABLE_COORDINATES["kitchen"][0]
        req.pose.pose.pose.position.y = TABLE_COORDINATES["kitchen"][1]
        req.pose.pose.pose.position.z = TABLE_COORDINATES["kitchen"][2]
        req.pose.pose.pose.orientation.w = 1.0
        req.pose.pose.covariance = [0.0] * 36  # 6x6 행렬 형식

        future = self.initial_pose_client.call_async(req)
        future.add_done_callback(self._initial_pose_callback)

    def _initial_pose_callback(self, future):
        try:
            response = future.result()
            self.get_logger().info("Initial pose set to kitchen successfully.")
        except Exception as e:
            self.get_logger().error(f"Failed to set initial pose: {e}")

    def send_turtlebot_goal(self, table_number):
        """TurtleBot3에 목표 좌표 전송"""
        if table_number not in TABLE_COORDINATES:
            self.get_logger().error(f"Invalid table number: {table_number}")
            return

        goal_pose = self._create_goal_pose(TABLE_COORDINATES[table_number])
        self._send_navigation_goal(goal_pose, lambda: self.return_to_kitchen())

    def return_to_kitchen(self):
        """TurtleBot3가 주방으로 복귀"""
        self.get_logger().info("Returning to kitchen...")
        kitchen_goal_pose = self._create_goal_pose(TABLE_COORDINATES["kitchen"])
        self._send_navigation_goal(kitchen_goal_pose)

    def _create_goal_pose(self, coordinates):
        """목표 위치 데이터를 생성"""
        x, y, z = coordinates
        goal_pose = PoseStamped()
        goal_pose.header.frame_id = "map"
        goal_pose.header.stamp = self.get_clock().now().to_msg()
        goal_pose.pose.position.x = float(x)
        goal_pose.pose.position.y = float(y)
        goal_pose.pose.position.z = float(z)
        goal_pose.pose.orientation.w = 1.0  # 기본 방향 설정
        return goal_pose

    def _send_navigation_goal(self, goal_pose, on_goal_reached=None):
        """목표 위치로 이동 명령 전송"""
        self.get_logger().info(f"Sending navigation goal: ({goal_pose.pose.position.x}, {goal_pose.pose.position.y})")
        if not self.action_client.wait_for_server(timeout_sec=5.0):
            self.get_logger().error("Action server not available!")
            return

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = goal_pose

        send_goal_future = self.action_client.send_goal_async(goal_msg)
        send_goal_future.add_done_callback(
            lambda future: self._handle_navigation_goal(future, on_goal_reached)
        )

    def _handle_navigation_goal(self, future, on_goal_reached):
        """목표 위치 도달 처리"""
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info("Goal rejected by the action server.")
            return

        self.get_logger().info("Goal accepted, waiting for result...")
        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(
            lambda result: self._handle_navigation_result(result, on_goal_reached)
        )

    def _handle_navigation_result(self, result, on_goal_reached):
        """목표 위치 도달 결과 처리"""
        status = result.result().status
        if status == 4:  # STATUS_SUCCEEDED
            self.get_logger().info("Goal succeeded!")
            if on_goal_reached:
                on_goal_reached()
        else:
            self.get_logger().error(f"Goal failed with status code: {status}")


class KitchenDisplay(QWidget):
    def __init__(self, node):
        super().__init__()
        self.node = node
        self.setWindowTitle("주방 디스플레이")
        self.setGeometry(100, 100, 800, 600)
        self.setStyleSheet("background-color: #2d2d2d; color: white; font-family: Arial, sans-serif;")

        # 메인 레이아웃
        main_layout = QVBoxLayout()

        # 상단 레이아웃 (짱PC, 날짜/시간)
        top_layout = QHBoxLayout()

        # 로고 이미지
        self.logo_label = QLabel(self)
        self.logo_pixmap = QPixmap('/home/jaeback/Pictures/Screenshots/PC.png')
        if not self.logo_pixmap.isNull():
            self.logo_label.setPixmap(self.logo_pixmap.scaled(90, 90, Qt.KeepAspectRatio))
        else:
            self.logo_label.setText("이미지 없음")
        self.logo_label.setAlignment(Qt.AlignCenter)

        # 텍스트 레이블
        self.jjangpc_label = QLabel("짱PC", self)
        self.jjangpc_label.setStyleSheet("font-size: 36px; font-weight: bold; color: #ffcc00; padding-left: 10px;")

        self.date_time_label = QLabel(self)
        self.update_date_time()
        self.date_time_label.setStyleSheet("font-size: 18px; color: #ffffff; padding-right: 10px;")

        top_layout.addWidget(self.logo_label)
        top_layout.addWidget(self.jjangpc_label)
        top_layout.addStretch()
        top_layout.addWidget(self.date_time_label)

        # 상단 레이아웃을 메인 레이아웃에 추가
        main_layout.addLayout(top_layout)

        # 테이블 및 메뉴 레이아웃
        self.grid_layout = QGridLayout()

        # 테이블 초기화
        self.tables = {i: {"menu": {}, "order_label": QLabel("주문 없음", self)} for i in range(1, 10)}

        # 9개의 칸으로 나누어 테이블 번호와 주문된 음식을 표시
        for i in range(9):
            room_label = QLabel(f"테이블 {i + 1}", self)
            room_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #ffffff; padding: 10px; background-color: #4caf50; text-align: center;")
            order_label = self.tables[i + 1]["order_label"]
            order_label.setStyleSheet("font-size: 14px; color: #ffffff; padding: 40px; background-color: #555555; text-align: center;")
            done_button = QPushButton("요리 완료", self)
            done_button.setStyleSheet("font-size: 14px; color: #ffffff; background-color: #f57c00; padding: 10px; border-radius: 5px;")
            done_button.clicked.connect(lambda _, table=i + 1: self.cook_done_clicked(table))
            room_frame = QFrame(self)
            room_layout = QVBoxLayout(room_frame)
            room_layout.addWidget(room_label)
            room_layout.addWidget(order_label)
            room_layout.addWidget(done_button)
            self.grid_layout.addWidget(room_frame, i // 3, i % 3)

        main_layout.addLayout(self.grid_layout)
        self.setLayout(main_layout)
        self.show()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_date_time)
        self.timer.start(1000)

        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self.update_table_display)
        self.update_timer.start(2000)

    def update_date_time(self):
        current_time = QDateTime.currentDateTime()
        formatted_time = current_time.toString("yyyy-MM-dd a h:mm")
        self.date_time_label.setText(formatted_time)

    def update_table_display(self):
        for table_number, orders in self.node.orders.items():
            order_label = self.tables[table_number]["order_label"]
            if orders:
                order_text = "\n".join([f"{item}: {quantity}개" for item, quantity in orders.items()])
                order_label.setText(order_text)
            else:
                order_label.setText("주문 없음")
                
    def cook_done_clicked(self, table_number):
        print(f"요리 완료 버튼 눌림: 테이블 {table_number}")
        self.node.send_turtlebot_goal(table_number)  # 이동 명령 전송


class RosNodeThread(QThread):
    def __init__(self, ros_node):
        super().__init__()
        self.ros_node = ros_node

    def run(self):
        rclpy.spin(self.ros_node)

    def stop(self):
        rclpy.shutdown()


def main():
    rclpy.init()
    kitchen_node = KitchenSubscriber()

    # ROS 노드를 별도 스레드에서 실행
    ros_thread = RosNodeThread(kitchen_node)
    ros_thread.start()

    app = QApplication(sys.argv)
    kitchen_display = KitchenDisplay(kitchen_node)
    kitchen_display.show()

    try:
        sys.exit(app.exec_())
    except KeyboardInterrupt:
        ros_thread.stop()


if __name__ == "__main__":
    main()
