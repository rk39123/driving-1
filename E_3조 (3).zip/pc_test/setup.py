from setuptools import setup

package_name = 'pc_test'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    py_modules=[
        'pc_test.PC_order',
        'pc_test.kitchen',
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='your_email@example.com',
    description='PC Order and Kitchen Display Nodes',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'pc_order = pc_test.PC_order:main',
            'kitchen = pc_test.kitchen:main',
        ],
    },
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/pc_test']),
        ('share/pc_test', ['package.xml']),  # 🚀 package.xml을 명시적으로 추가
    ],
)

