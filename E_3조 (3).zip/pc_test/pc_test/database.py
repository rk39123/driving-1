import mysql.connector

class SalesDataManager:
    def __init__(self):
        """MySQL 연결 정보를 self.db_config로 저장"""
        self.db_config = {
            "host": "localhost",
            "user": "pc_user",
            "password": "wns032715!",
            "database": "pc_db"
        }
        self.db_connection = mysql.connector.connect(
            host=self.db_config["host"],
            user=self.db_config["user"],
            password=self.db_config["password"],
            database=self.db_config["database"]
        )
        self.cursor = self.db_connection.cursor()

    def fetch_sales_data(self, date):
        """월별 매출 데이터 가져오기 (최신 데이터 반영 없이 단순 조회)"""
        try:
            connection = mysql.connector.connect(**self.db_config)  # autocommit 제외
            cursor = connection.cursor(dictionary=True)

            query = """
                SELECT DATE_FORMAT(timestamp, '%Y-%m-%d') AS sale_date, SUM(price * quantity) AS total_sales
                FROM orders
                WHERE DATE_FORMAT(timestamp, '%Y-%m') = %s
                GROUP BY sale_date
                ORDER BY sale_date ASC;
            """
            cursor.execute(query, (date,))
            sales_data = {row["sale_date"]: row["total_sales"] for row in cursor.fetchall()}

            cursor.close()
            connection.close()
            print(f"📊 [DEBUG] fetch_sales_data({date}): {sales_data}")  # 디버깅 로그 추가
            return sales_data

        except mysql.connector.Error as err:
            print(f"❌ Database Error: {err}")
            return {}

    def fetch_top_selling_items(self, date):
        """일별 가장 많이 팔린 메뉴 가져오기"""
        try:
            connection = mysql.connector.connect(**self.db_config)  # autocommit 제외
            cursor = connection.cursor(dictionary=True)

            query = """
                SELECT menu_item, SUM(quantity) AS total_sold
                FROM orders
                WHERE DATE_FORMAT(timestamp, '%Y-%m-%d') = %s
                GROUP BY menu_item
                ORDER BY total_sold DESC;
            """
            cursor.execute(query, (date,))
            top_items = {row["menu_item"]: row["total_sold"] for row in cursor.fetchall()}

            cursor.close()
            connection.close()
            return top_items

        except mysql.connector.Error as err:
            print(f"❌ Database Error: {err}")
            return {}
def save_order_to_db(table_id, menu_item, quantity, price):
    """MySQL에 주문 정보를 저장하는 함수"""
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="pc_user",
            password="wns032715!",
            database="pc_db",
            autocommit=True  # ✅ 최신 데이터 즉시 반영
        )
        cursor = connection.cursor()

        # ✅ MySQL orders 테이블에 데이터 삽입
        query = """
            INSERT INTO orders (table_id, menu_item, quantity, price, timestamp)
            VALUES (%s, %s, %s, %s, NOW())
        """
        values = (table_id, menu_item, quantity, price)

        cursor.execute(query, values)
        connection.commit()

        print(f"✅ 주문 저장 완료: 테이블 {table_id} - {menu_item} {quantity}개 ({price}원)")

    except mysql.connector.Error as err:
        print(f"❌ Database Error: {err}")
    finally:
        cursor.close()
        connection.close()
