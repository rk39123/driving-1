import sys
import json
import rclpy
import mysql.connector
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import PoseStamped
from nav2_msgs.srv import SetInitialPose
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QGridLayout, QFrame,
    QPushButton, QDialog, QTabWidget, QDateEdit
)
from PyQt5.QtCore import Qt, QDate, QDateTime, QTimer, QThread
from PyQt5.QtGui import QPixmap
from pc_test.database import SalesDataManager
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


matplotlib.rcParams['font.family'] = 'Noto Sans CJK JP'

TABLE_COORDINATES = {
    1: (0.7621728181838989, 1.0849592685699463, 1.0849592685699463),
    2: (0.8133512139320374, -0.02673669531941414, -0.001434326171875),
    3: (0.6820737719535828, -1.091596245765686, 0.002471923828125),
    4: (-0.26419275999069214, 1.07172429561615, -0.001434326171875),
    5: (-0.264366090297699, 0.004181892145425081, 0.001434326171875),
    6: (-0.2644293010234833, -1.0853710174560547, -0.00143426171875),
    7: (-1.5205914974212646, 1.0540658235549927, -0.001434326171875),
    8: (-1.382270336151123, -0.006906487513333559, -0.00143426171875),
    9: (-1.3768784999847412, -1.0530459804534912, -0.00143426171875),
    "kitchen": (-2.07126522064209, -0.4722866117954254, 0.002471923828125)  # 주방 좌표
}
# 📌 MySQL 데이터 관리 클래스
class SalesDataManager:
    def __init__(self):
        self.db_config = {
            "host": "localhost",
            "user": "pc_user",
            "password": "wns032715!",
            "database": "pc_db"
        }
        self.db_connection = mysql.connector.connect(**self.db_config)
        self.cursor = self.db_connection.cursor()

    def fetch_sales_data(self, date):
        """월별 매출 데이터 가져오기 (최신 데이터 즉시 반영)"""
        self.cursor.execute("""
            SELECT DATE_FORMAT(timestamp, '%Y-%m-%d') AS sale_date, SUM(price * quantity) AS total_sales
            FROM orders
            WHERE DATE_FORMAT(timestamp, '%Y-%m') = %s
            GROUP BY sale_date
            ORDER BY sale_date ASC;
        """, (date,))
    
        sales_data = {row[0]: row[1] for row in self.cursor.fetchall()}
    
        print(f"📊 [DEBUG] fetch_sales_data({date}): {sales_data}")  # ✅ 디버깅 로그 추가
        return sales_data
     
    def fetch_top_selling_items(self, date):
        query = """
            SELECT menu_item, SUM(quantity)
            FROM orders
            WHERE DATE_FORMAT(timestamp, '%Y-%m-%d') = %s
            GROUP BY menu_item
            ORDER BY SUM(quantity) DESC;
        """
        self.cursor.execute(query, (date,))
        return dict(self.cursor.fetchall())

class KitchenSubscriber(Node):
    def __init__(self):
        super().__init__('kitchen_subscriber')
        self.serving_status = {}
        self.total_revenue = 0
        self.accumulated_orders = {}
        self.subscription = self.create_subscription(
            String,
            'order_topic',
            self.listener_callback,
            10
        )
        self.publisher = self.create_publisher(PoseStamped, '/goal_pose', 10)
        self.orders = {}
        self.total_revenue = 0

        # 새로운 변수: 누적 매출 및 판매된 품목 통계
        self.accumulated_orders = {}  # 품목별 판매 수량 누적 저장
        self.total_revenue = 0  # 누적 매출액

        self.serving_status = {}
        self.initial_pose_client = self.create_client(SetInitialPose, '/set_initial_pose')
        self.action_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        while not self.initial_pose_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /set_initial_pose service...')
        self.set_initial_pose_to_kitchen()

    def listener_callback(self, msg):
        """ROS2 토픽에서 주문 데이터를 수신하는 콜백 함수"""
        try:
            data = json.loads(msg.data)
            table_number = data['table_number']
            cart_items = data['cart_items']

            if table_number not in self.orders:
                self.orders[table_number] = {}
            self.orders[table_number].update(cart_items)

            for item, (price, quantity) in cart_items.items():
                # 누적 품목 통계 업데이트
                self.accumulated_orders[item] = self.accumulated_orders.get(item, 0) + quantity

                # 누적 매출액 추가
                self.total_revenue += price * quantity

            self.get_logger().info(f"Received order: {data}")
            if hasattr(self, 'ui'):
                self.ui.update_table_display()
                QApplication.processEvents()  # 🔥 UI 즉시 반영
            else:
                self.get_logger().error
        except Exception as e:
            self.get_logger().error(f"Error processing order message: {e}")
            
    def update_serving_status(self, table_number, status_message):
        """서빙 상태를 업데이트하는 메서드"""
        self.serving_status[table_number] = status_message    

    def set_initial_pose_to_kitchen(self):
        """TurtleBot3 초기 위치를 주방으로 설정"""
        if "kitchen" not in TABLE_COORDINATES:
            self.get_logger().error("Kitchen coordinates are missing!")
            return

        x, y, z = TABLE_COORDINATES["kitchen"]

        req = SetInitialPose.Request()
        req.pose.header.frame_id = 'map'
        req.pose.pose.pose.position.x = x
        req.pose.pose.pose.position.y = y
        req.pose.pose.pose.position.z = z
        req.pose.pose.pose.orientation.w = 1.0  # 기본 방향 설정
        req.pose.pose.covariance = [0.0] * 36  # 6x6 행렬 형식

        self.get_logger().info("Setting initial pose to kitchen...")

        future = self.initial_pose_client.call_async(req)
        future.add_done_callback(self._initial_pose_callback)

    def _initial_pose_callback(self, future):
        try:
            response = future.result()
            self.get_logger().info("✅ Initial pose set to kitchen successfully.")
        except Exception as e:
            self.get_logger().error(f"❌ Failed to set initial pose: {e}")
            
    def send_turtlebot_goal(self, table_number):
        """TurtleBot3에 목표 좌표 전송"""
        if table_number not in TABLE_COORDINATES:
            self.get_logger().error(f"Invalid table number: {table_number}")
            return

        goal_pose = self._create_goal_pose(TABLE_COORDINATES[table_number])

        # ✅ 서빙 시작 상태 저장 (UI 업데이트)
        self.serving_status[table_number] = f"🚗 로봇이 {table_number}번 테이블 서빙 중입니다!"
        print("1, 서빙 시작")
        self.get_logger().info(self.serving_status[table_number])

        self._send_navigation_goal(goal_pose, lambda: self.return_to_kitchen(table_number))

    def return_to_kitchen(self, table_number):
        self.get_logger().info(f"Returning to kitchen after serving Table {table_number}...")

        kitchen_goal_pose = self._create_goal_pose(TABLE_COORDINATES["kitchen"])    
    
        def after_arrival():
            # ✅ 테이블별 주문 목록 초기화
            if table_number in self.orders:
                self.get_logger().info(f"🗑️ 주문 초기화: 테이블 {table_number}")
                self.orders[table_number] = {}

        # ✅ 서빙 상태 업데이트
            self.serving_status[table_number] = f"✅ 로봇이 {table_number}번 테이블 서빙을 완료했습니다!"
            self.get_logger().info(self.serving_status[table_number])

        # ✅ UI 강제 갱신
            if hasattr(self, 'ui'):
                self.ui.update_table_display()  # 주문 UI 업데이트
                self.ui.update_robot_status()  # 로봇 상태 UI 업데이트
                QApplication.processEvents()  # UI 즉시 반영

    # ✅ 주방 도착 후 주문 초기화 실행
        self._send_navigation_goal(kitchen_goal_pose, on_goal_reached=after_arrival)

    def _create_goal_pose(self, coordinates):
        """목표 위치 데이터를 생성"""
        x, y, z = coordinates
        goal_pose = PoseStamped()
        goal_pose.header.frame_id = "map"
        goal_pose.header.stamp = self.get_clock().now().to_msg()
        goal_pose.pose.position.x = float(x)
        goal_pose.pose.position.y = float(y)
        goal_pose.pose.position.z = float(z)
        goal_pose.pose.orientation.w = 1.0
        return goal_pose

    def _send_navigation_goal(self, goal_pose, on_goal_reached=None):
        """목표 위치로 이동 명령 전송"""
        self.get_logger().info(f"📍 Sending navigation goal: ({goal_pose.pose.position.x}, {goal_pose.pose.position.y})")

        if not self.action_client.wait_for_server(timeout_sec=5.0):
            self.get_logger().error("❌ Action server not available!")
            return

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = goal_pose

        send_goal_future = self.action_client.send_goal_async(goal_msg)
        send_goal_future.add_done_callback(
            lambda future: self._handle_navigation_goal(future, on_goal_reached)
        )

    def _handle_navigation_goal(self, future, on_goal_reached):
        """목표 위치 도달 처리"""
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info("❌ Goal rejected by the action server.")
            return

        self.get_logger().info("✅ Goal accepted, waiting for result...")
        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(
            lambda result: self._handle_navigation_result(result, on_goal_reached)
        )

    def _handle_navigation_result(self, result, on_goal_reached):
        """목표 위치 도달 결과 처리"""
        status = result.result().status
        if status == 4:  # STATUS_SUCCEEDED
            self.get_logger().info("🎯 Goal succeeded!")
            if on_goal_reached:
                on_goal_reached()
        else:
            self.get_logger().error(f"❌ Goal failed with status code: {status}")


class KitchenDisplay(QWidget):
    def __init__(self, node):
        super().__init__()
        self.node = node
        self.data_manager = SalesDataManager()  # MySQL 데이터 관리 객체 생성
        self.init_ui()


    def init_ui(self):
        self.setWindowTitle("주방 디스플레이")
        self.setGeometry(100, 100, 800, 600)
        self.setStyleSheet("background-color: #2d2d2d; color: white; font-family: Arial, sans-serif;")

        main_layout = QVBoxLayout()

        # 상태 표시 라벨 추가
        self.status_label = QLabel("로봇 상태: 대기 중", self)
        self.status_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #FFFFFF; text-align: center;")
        main_layout.addWidget(self.status_label)
        self.status_label.setFixedSize(400,50)

        # 상단: 로봇 상태 및 매장 관리 버튼
        top_layout = QHBoxLayout()

        # 로고 이미지
        self.logo_label = QLabel(self)
        self.logo_pixmap = QPixmap('/home/songhyun/ros2_ws/src/pc_test/image/PC.png' )
        if not self.logo_pixmap.isNull():
            self.logo_label.setPixmap(self.logo_pixmap.scaled(90, 90, Qt.KeepAspectRatio))
        else:
            self.logo_label.setText("이미지 없음")
        self.logo_label.setAlignment(Qt.AlignCenter)

        # 텍스트 레이블
        self.jjangpc_label = QLabel("짱PC", self)
        self.jjangpc_label.setStyleSheet("font-size: 36px; font-weight: bold; color: #ffcc00; padding-left: 10px;")

        self.date_time_label = QLabel(self)
        self.update_date_time()
        self.date_time_label.setStyleSheet("font-size: 18px; color: #ffffff; padding-right: 10px;")

        top_layout.addWidget(self.logo_label)
        top_layout.addWidget(self.jjangpc_label)
        top_layout.addStretch()
        top_layout.addWidget(self.date_time_label)

        main_layout.addLayout(top_layout)

        # 매장 관리 버튼을 누르면 새 UI 실행
        self.manage_button = QPushButton("매장 관리")
        self.manage_button.setStyleSheet("font-size: 18px; color: #ffffff; background-color: #0056a8; padding: 10px; border-radius: 5px;")
        self.manage_button.clicked.connect(self.open_management_dialog)
        main_layout.addWidget(self.manage_button)

        # 테이블 및 메뉴 레이아웃
        self.grid_layout = QGridLayout()
        self.tables = {i: {"menu": {}, "order_label": QLabel("주문 없음", self)} for i in range(1, 10)}

        for i in range(9):
            room_label = QLabel(f"테이블 {i + 1}", self)
            room_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #ffffff; padding: 10px; background-color: #4caf50; text-align: center;")
            order_label = self.tables[i + 1]["order_label"]
            order_label.setStyleSheet("font-size: 14px; color: #ffffff; padding: 40px; background-color: #555555; text-align: center;")
            done_button = QPushButton("요리 완료", self)
            done_button.setStyleSheet("font-size: 14px; color: #ffffff; background-color: #f57c00; padding: 10px; border-radius: 5px;")
            done_button.clicked.connect(lambda _, table=i + 1: self.cook_done_clicked(table))
            room_frame = QFrame(self)
            room_layout = QVBoxLayout(room_frame)
            room_layout.addWidget(room_label)
            room_layout.addWidget(order_label)
            room_layout.addWidget(done_button)
            self.grid_layout.addWidget(room_frame, i // 3, i % 3)

        main_layout.addLayout(self.grid_layout)
        self.setLayout(main_layout)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_date_time)
        self.timer.start(1000)      

        # 실시간 갱신 타이머 제거 -> update_table_display와 관련된 QTimer 제거

    def open_management_dialog(self):
        """매장 관리 버튼을 누르면 ManagementUI 실행"""
        self.management_dialog = ManagementUI(self.data_manager, self)
        self.management_dialog.exec_()

    def update_date_time(self):
        current_time = QDateTime.currentDateTime()
        formatted_time = current_time.toString("yyyy-MM-dd a h:mm")
        self.date_time_label.setText(formatted_time)

    def update_table_display(self):
        """테이블 주문 정보를 UI에 업데이트"""
        for table_number, orders in self.node.orders.items():
            if table_number in self.tables:
                order_label = self.tables[table_number]["order_label"]
                if orders:
                    order_text = "\n".join([f"{item}: {details[1]}개" for item, details in orders.items()])
                    order_label.setText(order_text)
                    self.get_logger().info(f"✅ 테이블 {table_number} 주문 UI 업데이트됨: {order_text}")
                else:
                    order_label.setText("주문 없음")
            else:
                self.get_logger().error(f"❌ UI 업데이트 실패: 테이블 {table_number}가 self.tables에 없음!")
    def cook_done_clicked(self, table_number):
        """요리 완료 버튼을 누르면 로봇이 테이블로 이동"""
        print(f"요리 완료 버튼 눌림: 테이블 {table_number}")
        self.node.send_turtlebot_goal(table_number)  # 이동 명령 전송
        self.update_robot_status()

    def update_robot_status(self):
        """KitchenSubscriber의 서빙 상태를 가져와 UI에 반영"""
        if self.node.serving_status:
            latest_status = list(self.node.serving_status.values())[-1]
            self.status_label.setText(latest_status)
        else:
            self.status_label.setText("로봇 상태: 대기 중")

class ManagementDialog(QDialog):
    def __init__(self, node, parent=None):
        super().__init__(parent)
        self.node = node
        self.setWindowTitle("매장 관리")
        self.setGeometry(200, 200, 800, 600)
        self.setStyleSheet("""
            background-color: #2d2d2d;
            color: white;
            font-family: Arial, sans-serif;
            font-size: 16px;
        """)

        layout = QVBoxLayout()

        # 남은 시간 표시
        remaining_time_label = QLabel("남은 시간:")
        remaining_time_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #4CAF50;")
        layout.addWidget(remaining_time_label)

        # 가장 많이 팔린 메뉴 그래프
        layout.addWidget(QLabel("오늘의 판매량 (가장 많이 팔린 메뉴)"))
        self.plot_most_sold_item(layout)

        # 총 매출액 탭
        tab_widget = QTabWidget(self)
        tabs_data = self.get_sales_by_category()

        for tab_name, data in tabs_data.items():
            tab = QWidget()
            tab_layout = QVBoxLayout(tab)
            total_sales = 0
            for item, sales in data.items():
                tab_layout.addWidget(QLabel(f"{item}: {sales} 원"))
                total_sales += sales
            tab_layout.addWidget(QLabel(f"합계: {total_sales} 원"))
            tab_widget.addTab(tab, tab_name)

        layout.addWidget(tab_widget)
        self.setLayout(layout)

    def plot_most_sold_item(self, layout):
        # matplotlib 그래프 추가
        figure = Figure()
        canvas = FigureCanvas(figure)
        ax = figure.add_subplot(111)

        # accumulated_orders를 이용한 그래프 데이터
        data = self.node.accumulated_orders
        items = list(data.keys())
        values = list(data.values())

        ax.barh(items, values, color="#4CAF50")
        ax.set_xlabel("판매량")
        ax.set_title("오늘의 판매량")
        ax.invert_yaxis()

        layout.addWidget(canvas)

        if items:
            most_sold = max(data, key=data.get)
            layout.addWidget(QLabel(f"가장 많이 팔린 음식은 {most_sold}입니다."))

    def get_sales_by_category(self):
        # 기존 accumulated_orders를 통해 카테고리별 매출 계산
        categories = {
            "라면": ["불닭볶음면", "짜계치", "해장라면", "떡라면"],
            "간식": ["치킨", "떡볶이", "소떡소떡", "감자튀김"],
            "밥": ["김치볶음밥", "스팸볶음밥", "새우볶음밥"],
            "음료": ["콜라", "사이다", "아이스티", "아이스커피", "물"],
            "한정판": ["삼겹살 정식"]
        }

        menu_prices = {
            "불닭볶음면": 2500, "짜계치": 3000, "해장라면": 3000, "떡라면": 3500,
            "치킨": 3000, "떡볶이": 3500, "소떡소떡": 2000, "감자튀김": 2500,
            "김치볶음밥": 3500, "스팸볶음밥": 4000, "새우볶음밥": 4500,
            "콜라": 2000, "사이다": 2000, "아이스티": 2500, "아이스커피": 1900, "물": 1500,
            "삼겹살 정식": 6000
        }

        category_sales = {cat: {} for cat in categories}
        for item, total_qty in self.node.accumulated_orders.items():
            for cat, items in categories.items():
                if item in items:
                    price = menu_prices.get(item, 0)
                    category_sales[cat][item] = total_qty * price
                    break

        return category_sales

    def calculate_statistics(self):
        # self.node.accumulated_orders와 self.node.total_revenue를 기반으로 통계 계산
        total_revenue = self.node.total_revenue
        accumulated_orders = self.node.accumulated_orders

        # 품목 판매량 통계 계산
        most_sold_item = max(accumulated_orders, key=accumulated_orders.get, default="없음")

        # 삼겹살 정식 재고 계산
        max_stock = 10
        limited_stock_left = max_stock - accumulated_orders.get("삼겹살 정식", 0)

        return total_revenue, most_sold_item, limited_stock_left
# 📌 매장 관리 UI
class ManagementUI(QDialog):
    def __init__(self, data_manager, parent=None):
        super().__init__(parent)
        self.data_manager = data_manager
        self.setWindowTitle("매장 관리 시스템")
        self.setGeometry(200, 200, 1000, 600)
        layout = QVBoxLayout()

        self.date_picker = QDateEdit()
        self.date_picker.setCalendarPopup(True)
        self.date_picker.setDate(QDate.currentDate())
        self.date_picker.dateChanged.connect(self.update_statistics)
        layout.addWidget(self.date_picker)

        self.tabs = QTabWidget()
        self.revenue_tab = QWidget()
        self.sales_tab = QWidget()
        self.tabs.addTab(self.revenue_tab, "📊 매출 현황")
        self.tabs.addTab(self.sales_tab, "🍽️ 인기 메뉴")
        layout.addWidget(self.tabs)
        self.setLayout(layout)

        self.init_revenue_tab()
        self.init_sales_tab()
        self.update_statistics()  # 이 부분을 수동으로 호출할 때만 갱신

    def init_revenue_tab(self):
        self.revenue_tab.layout = QVBoxLayout()

        # 🔹 매출 정보 텍스트 추가 (여기에 매출 현황 표시)
        self.revenue_label = QLabel("매출 데이터를 불러오는 중...")
        self.revenue_label.setStyleSheet("font-size: 16px; font-weight: bold; color: white;")
        self.revenue_tab.layout.addWidget(self.revenue_label)

        self.revenue_canvas = FigureCanvas(plt.Figure())
        self.revenue_tab.layout.addWidget(self.revenue_canvas)
        self.revenue_tab.setLayout(self.revenue_tab.layout)
    
    def init_sales_tab(self):
        self.sales_tab.layout = QVBoxLayout()
        self.sales_canvas = FigureCanvas(plt.Figure())
        self.sales_tab.layout.addWidget(self.sales_canvas)
        self.sales_tab.setLayout(self.sales_tab.layout)
    
    def update_statistics(self):
        selected_date = self.date_picker.date().toString("yyyy-MM")  # YYYY-MM 형식 (월별)
        daily_date = self.date_picker.date().toString("yyyy-MM-dd")  # YYYY-MM-DD 형식 (날짜별)

        sales_data = self.data_manager.fetch_sales_data(selected_date)  # 월별 매출 가져오기
        top_selling_items = self.data_manager.fetch_top_selling_items(daily_date)  # 인기 메뉴 가져오기

        self.update_revenue_chart(sales_data)
        self.update_sales_chart(top_selling_items)
        self.update_revenue_label(sales_data, daily_date)

    def update_revenue_chart(self, sales_data):
        self.revenue_canvas.figure.clear()
        ax = self.revenue_canvas.figure.add_subplot(111)
        if sales_data:
            dates, revenues = zip(*sorted(sales_data.items()))
            ax.plot(dates, revenues, marker="o", linestyle="-", color="#ff6699")
            ax.set_xlabel("날짜")
            ax.set_ylabel("매출 (원)")
            ax.set_title("매출 변화 추이")
        else:
            ax.text(0.5, 0.5, "데이터 없음", ha='center', va='center', fontsize=14)
        self.revenue_canvas.draw()
    
    def update_sales_chart(self, sales_data):
        self.sales_canvas.figure.clear()
        ax = self.sales_canvas.figure.add_subplot(111)
        if sales_data:
            items, quantities = zip(*sales_data.items())
            ax.barh(items, quantities, color='#66ccff')
            ax.set_xlabel("판매 개수")
            ax.set_title("인기 메뉴")
        else:
            ax.text(0.5, 0.5, "데이터 없음", ha='center', va='center', fontsize=14)
        self.sales_canvas.draw()

    def update_revenue_label(self, sales_data, daily_date):
        """🔹 매출 정보를 텍스트로 표시하는 함수"""
        total_monthly_revenue = sum(sales_data.values()) if sales_data else 0
        daily_revenue = sales_data.get(daily_date, 0)  # 선택한 날짜의 매출 가져오기

        selected_month = self.date_picker.date().toString("yyyy년 MM월")
        selected_day = self.date_picker.date().toString("yyyy년 MM월 dd일")

        revenue_text = f"""
        @ {selected_month} 총 매출: {total_monthly_revenue:,}원
        @ {selected_day} 총 매출: {daily_revenue:,}원
        """

        self.revenue_label.setText(revenue_text)

class RosNodeThread(QThread):
    def __init__(self, ros_node):
        super().__init__()
        self.ros_node = ros_node

    def run(self):
        rclpy.spin(self.ros_node)

    def stop(self):
        rclpy.shutdown()


def main():
    rclpy.init()
    kitchen_node = KitchenSubscriber()

    app = QApplication(sys.argv)
    kitchen_display = KitchenDisplay(kitchen_node)

    # ✅ KitchenSubscriber가 KitchenDisplay를 참조하도록 설정
    kitchen_node.ui = kitchen_display

    kitchen_display.show()

    ros_thread = RosNodeThread(kitchen_node)
    ros_thread.start()

    try:
        sys.exit(app.exec_())
    except KeyboardInterrupt:
        ros_thread.stop()

if __name__ == "__main__":
    main() 
