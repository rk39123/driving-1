import sys
import json
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from PyQt5.QtWidgets import (
    QDialog, QApplication, QMainWindow, QPushButton, QVBoxLayout, QLabel, QGridLayout,
    QTabWidget, QHBoxLayout, QWidget, QGroupBox, QMessageBox, QSpinBox, QScrollArea, 
    QFrame, QTableWidget, QTableWidgetItem, QTextEdit 
)

from PyQt5.QtCore import QTimer, QTime, QDate, Qt
from PyQt5.QtGui import QPixmap, QFont
from PyQt5.QtCore import QThread
from pc_test.database import save_order_to_db

class OrderPublisher(Node):
    def __init__(self):
        super().__init__('order_publisher')
        self.publisher = self.create_publisher(String, 'order_topic', 10)

    def publish_order(self, order_data):
        msg = String()
        msg.data = json.dumps(order_data, ensure_ascii=False)
        self.publisher.publish(msg)
        self.get_logger().info(f'Published order: {msg.data}')

class RosNodeThread(QThread):
    def __init__(self, ros_node):
        super().__init__()
        self.ros_node = ros_node

    def run(self):
        rclpy.spin(self.ros_node)  # ROS 노드 실행

    def stop(self):
        rclpy.shutdown()  # ROS 종료

class PCCafe(QMainWindow):
    def __init__(self, ros_node):
        super().__init__()
        self.ros_node = ros_node  # ROS 노드를 생성자에서 전달받아 저장
        self.setWindowTitle("짱pc")
        self.setGeometry(100, 100, 1000, 700)  # 넓은 창 크기 설정

                # ✅ 메뉴별 가격 설정
        self.menu_prices = {
            "불닭볶음면": 2500, "짜계치": 3000, "해장라면": 3000, "떡라면": 3500,
            "치킨": 3000, "떡볶이": 3500, "소떡소떡": 2000, "감자튀김": 2500,
            "김치볶음밥": 3500, "스팸볶음밥": 4000, "새우볶음밥": 4500,
            "콜라": 2000, "사이다": 2000, "아이스티": 2500, "아이스커피": 1900, "물": 1500,
            "삼겹살 정식": 6000
        }

        # 테이블 상태 관리
        self.tables = {i: None for i in range(1, 10)}
        self.table_order_history = {i: [] for i in range(1, 10)}  # 각 테이블의 주문 내역
        self.special_menu_stock = {"삼겹살 정식": 10}  # 한정판 재고
        self.cart_items = {}  # 장바구니: {메뉴 이름: [가격, 수량]}
        self.current_table = None  # 현재 선택된 테이블

        self.initUI()

    def initUI(self):
        self.main_layout = QVBoxLayout()
        self.main_layout.setSpacing(0)
        self.main_layout.setContentsMargins(0, 0, 0, 0)

        # 상단 정보
        header_layout = QHBoxLayout()

        title_label = QLabel("짱pc")
        title_label.setFont(QFont("Arial", 24, QFont.Bold))
        title_label.setStyleSheet("color: white;")
        header_layout.addWidget(title_label, alignment=Qt.AlignLeft)

        date_label = QLabel(QDate.currentDate().toString("yyyy-MM-dd"))
        date_label.setFont(QFont("Arial", 18))
        date_label.setStyleSheet("color: white;")
        header_layout.addStretch()
        header_layout.addWidget(date_label, alignment=Qt.AlignRight)

        self.main_layout.addLayout(header_layout)

        # 테이블 선택 버튼
        table_layout = QGridLayout()
        table_layout.setSpacing(20)
        
        for i in range(1, 10):
            btn = QPushButton(f"테이블 {i}")
            btn.setFont(QFont("Arial", 18, QFont.Bold))
            btn.setStyleSheet("background-color: #87CEEB; color: black; border: 2px solid #1E90FF; border-radius: 10px; padding: 20px;")
            btn.clicked.connect(lambda _, table=i: self.selectTable(table))
            table_layout.addWidget(btn, (i-1)//3, (i-1)%3)

        table_layout.setContentsMargins(50, 20, 50, 50)  # 여백 추가
        self.main_layout.addLayout(table_layout)

        self.central_widget = QWidget()
        self.central_widget.setLayout(self.main_layout)
        self.central_widget.setStyleSheet("background-color: #4682B4;")
        self.setCentralWidget(self.central_widget)

    def selectTable(self, table):
        if self.tables[table] is not None:
            QMessageBox.warning(self, "이미 할당된 좌석", "이미 할당된 좌석입니다. 다른 좌석을 선택해주세요.")
            return

        self.current_table = table
        self.showTableScreen(table)

    def showTableScreen(self, table):
        self.clearLayout(self.main_layout)

        # 선택된 테이블 번호
        table_label = QLabel(f"선택된 테이블: {table}번")
        table_label.setFont(QFont("Arial", 18))
        table_label.setStyleSheet("color: white;")
        self.main_layout.addWidget(table_label)

        # 시간 선택 안내
        time_label = QLabel("몇 시간 동안 사용할지 선택하세요:")
        time_label.setFont(QFont("Arial", 16))
        time_label.setStyleSheet("color: white;")
        self.main_layout.addWidget(time_label)

        # 시간 선택 버튼
        time_layout = QGridLayout()
        time_layout.setSpacing(30)

        for i in range(1, 5):
            btn = QPushButton(f"{i}시간")
            btn.setFont(QFont("Arial", 18, QFont.Bold))
            btn.setStyleSheet("background-color: #87CEEB; color: black; border: 2px solid #1E90FF; border-radius: 10px; padding: 50px;")
            btn.clicked.connect(lambda _, hours=i: self.allocateTime(table, hours))
            time_layout.addWidget(btn, 0, i - 1)

        time_layout.setContentsMargins(50, 20, 50, 50)
        self.main_layout.addLayout(time_layout)

        # Clear overlapping background
        self.central_widget = QWidget()
        self.central_widget.setStyleSheet("background-color: #4682B4;")
        self.central_widget.setLayout(self.main_layout)
        self.setCentralWidget(self.central_widget)

    def allocateTime(self, table, hours):
        self.tables[table] = QTime.currentTime().addSecs(hours * 3600)
        QMessageBox.information(self, "시간 할당 완료", f"{hours}시간이 할당되었습니다.")
        self.showMenuScreen(table, hours)

    def showMenuScreen(self, table, hours):
        self.clearLayout(self.main_layout)

        # 상단 남은 시간 표시 및 홈 버튼
        header_layout = QHBoxLayout()

        self.timer_label = QLabel(f"남은 시간: {hours}:00")
        self.timer_label.setFont(QFont("Arial", 18))
        self.timer_label.setStyleSheet("color: white;")
        header_layout.addWidget(self.timer_label)

        home_btn = QPushButton("홈으로")
        home_btn.setFont(QFont("Arial", 14))
        home_btn.setStyleSheet("background-color: #FF6347; color: white; border: 2px solid #FF4500; border-radius: 10px;")
        home_btn.clicked.connect(self.initUI)
        header_layout.addWidget(home_btn)

        self.main_layout.addLayout(header_layout)

        # 탭 메뉴 구성
        tab_widget = QTabWidget()
        tab_widget.setStyleSheet("QTabBar::tab { background: #4682B4; color: white; padding: 10px; border-radius: 5px; } QTabBar::tab:selected { background: #1E90FF; font-weight: bold; }")

        # 라면 종류 탭
        ramen_tab = self.createMenuTab("라면 종류", ["불닭볶음면", "짜계치", "해장라면", "떡라면"])
        tab_widget.addTab(ramen_tab, "라면")

        # 간식 종류 탭
        snack_tab = self.createMenuTab("간식", ["치킨", "떡볶이", "소떡소떡", "감자튀김"])
        tab_widget.addTab(snack_tab, "간식")

        # 밥 종류 탭
        rice_tab = self.createMenuTab("밥 종류", ["김치볶음밥", "스팸볶음밥", "새우볶음밥"])
        tab_widget.addTab(rice_tab, "밥")

        # 음료수 탭
        drink_tab = self.createMenuTab("음료수", ["콜라", "사이다", "아이스티", "아이스커피", "물"])
        tab_widget.addTab(drink_tab, "음료수")

        # 한정판 탭
        special_tab = self.createMenuTab("한정판", ["삼겹살 정식"])
        tab_widget.addTab(special_tab, "한정판")

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)  # 크기 자동 조절 허용

        #   기존 메뉴판을 새로운 위젯에 추가
        menu_container = QWidget()
        menu_layout = QVBoxLayout(menu_container)
        menu_layout.addWidget(tab_widget)  # 기존 메뉴 탭 추가
        menu_container.setLayout(menu_layout)

        scroll_area.setWidget(menu_container)  # 스크롤 영역에 추가

        # 스크롤 영역을 메인 레이아웃에 추가
        self.main_layout.addWidget(scroll_area)

        # 장바구니 및 주문 버튼
        cart_layout = QVBoxLayout()

        cart_label = QLabel("장바구니")
        cart_label.setFont(QFont("Arial", 18))
        cart_label.setStyleSheet("color: white;")
        cart_layout.addWidget(cart_label)

        self.cart = QVBoxLayout()
        cart_scroll = QScrollArea()
        cart_scroll_widget = QWidget()
        cart_scroll_widget.setLayout(self.cart)
        cart_scroll.setWidget(cart_scroll_widget)
        cart_scroll.setWidgetResizable(True)
        cart_scroll.setFixedHeight(250)
        cart_scroll.setStyleSheet("background-color: #F0F8FF; border: 1px solid #1E90FF; border-radius: 10px;")
        cart_layout.addWidget(cart_scroll)

        order_layout = QHBoxLayout()
        order_btn = QPushButton("주문")
        order_btn.setFont(QFont("Arial", 14))
        order_btn.setStyleSheet("background-color: #32CD32; color: white; border: 2px solid #228B22; border-radius: 10px;")
        order_btn.clicked.connect(self.placeOrder)
        order_layout.addWidget(order_btn)

        history_btn = QPushButton("주문 내역 확인")
        history_btn.setFont(QFont("Arial", 14))
        history_btn.setStyleSheet("background-color: #FFA500; color: white; border: 2px solid #FF8C00; border-radius: 10px;")
        history_btn.clicked.connect(lambda: self.showOrderHistory(self.current_table))
        order_layout.addWidget(history_btn)

        cart_layout.addLayout(order_layout)

        cart_widget_container = QWidget()
        cart_widget_container.setLayout(cart_layout)
        self.main_layout.addWidget(cart_widget_container)

        self.central_widget.setLayout(self.main_layout)

    def createMenuTab(self, category, items):
        tab_layout = QGridLayout()
        tab_layout.setSpacing(10)

        menu_images = {
            "불닭볶음면": "/home/songhyun/ros2_ws/src/pc_test/image/불닭볶음면.png",
            "짜계치": "/home/songhyun/ros2_ws/src/pc_test/image/짜계치.png",
            "감자튀김": "/home/songhyun/ros2_ws/src/pc_test/image/감자튀김.png",
            "스팸볶음밥": "/home/songhyun/ros2_ws/src/pc_test/image/스팸볶음밥.png",
            "김치볶음밥": "/home/songhyun/ros2_ws/src/pc_test/image/김치볶음밥.png",
            "떡라면": "/home/songhyun/ros2_ws/src/pc_test/image/떡라면.png",
            "떡볶이": "/home/songhyun/ros2_ws/src/pc_test/image/떡볶이.png",
            "물": "/home/songhyun/ros2_ws/src/pc_test/image/물.jpg",
            "사이다": "/home/songhyun/ros2_ws/src/pc_test/image/사이다.jpg",
            "삼겹살 정식": "/home/songhyun/ros2_ws/src/pc_test/image/삼겹살 정식.png",
            "새우볶음밥": "/home/songhyun/ros2_ws/src/pc_test/image/새우볶음밥.png",
            "소떡소떡": "/home/songhyun/ros2_ws/src/pc_test/image/소떡소떡.png",
            "아이스커피": "/home/songhyun/ros2_ws/src/pc_test/image/아이스커피.jpg",
            "아이스티": "/home/songhyun/ros2_ws/src/pc_test/image/아이스티.jpg",
            "초코라떼": "/home/songhyun/ros2_ws/src/pc_test/image/초코라떼.jpg",
            "치킨": "/home/songhyun/ros2_ws/src/pc_test/image/치킨.png",
            "콜라": "/home/songhyun/ros2_ws/src/pc_test/image/콜라.jpg",
            "해장라면": "/home/songhyun/ros2_ws/src/pc_test/image/해장라면.png"
        }
        default_image_path = "/home/songhyun/ros2_ws/src/pc_test/image/default.png"

        for row, item in enumerate(items):
            image_path = menu_images.get(item, default_image_path)

            print(f"🔍 Loading image: {image_path}")
            
            image_label = QLabel()
            image_label.setFixedSize(140, 140)
            image_label.setScaledContents(True)

            image_label.setAlignment(Qt.AlignCenter)
            image_label.setStyleSheet("border: 1px solid #1E90FF; border-radius: 10px;")

            pixmap = QPixmap()
            if not pixmap.load(image_path):
                pixmap.load(default_image_path)

            image_label.setPixmap(pixmap)
            image_label.setScaledContents(True)

            price = self.menu_prices.get(item, 3000)
            item_label = QLabel(f"{item}\n{price}원")
            item_label.setFont(QFont("Arial", 12))
            item_label.setStyleSheet("color: white;")
            item_label.setAlignment(Qt.AlignCenter)

            tag_label = QLabel()
            tag_label.setFont(QFont("Arial", 10))
            tag_label.setAlignment(Qt.AlignCenter)
            tag_label.setFixedHeight(20)
            if item in ["불닭볶음면", "짜계치", "치킨"]:  # 인기 메뉴
                tag_label.setText("🔥 Best Seller")
                tag_label.setStyleSheet("background-color: red; color: white; border-radius: 5px; padding: 3px;")
            elif item in ["소떡소떡", "떡볶이"]:  # 새로 나온 메뉴
                tag_label.setText("🆕 New")
                tag_label.setStyleSheet("background-color: blue; color: white; border-radius: 5px; padding: 3px;")
            else:
                tag_label.setText("")

            add_btn = QPushButton("추가")
            add_btn.setFont(QFont("Arial", 12))
            add_btn.setFixedSize(100, 40)
            add_btn.setStyleSheet("""
                QPushButton {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #4CAF50, stop:1 #45A049);
                    color: white;
                    border-radius: 10px;
                    border: 2px solid #388E3C;
                    font-size: 14px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #45A049, stop:1 #388E3C);
                }
            """)  
            add_btn.clicked.connect(lambda _, name=item, p=price: self.addToCart(name, p))

            item_container = QVBoxLayout()
            item_container.setAlignment(Qt.AlignCenter)
            item_container.addWidget(tag_label, alignment=Qt.AlignCenter)
            item_container.addWidget(image_label, alignment=Qt.AlignCenter)
            item_container.addWidget(item_label, alignment=Qt.AlignCenter)
            item_container.addWidget(add_btn, alignment=Qt.AlignCenter)

            container = QWidget()
            container.setLayout(item_container)
            container.setStyleSheet("""
                QWidget {
                    background-color: #1E90FF;
                    border-radius: 15px;
                    padding: 10px;
                }
            """)

            tab_layout.addWidget(container, row // 3, row % 3)

        tab_widget = QWidget()
        tab_widget.setLayout(tab_layout)
        return tab_widget

    def createSpecialMenuTab(self, category, items, prices):
        return self.createMenuTab(category, items)

    def addToCart(self, item, price):

        if item == "삼겹살 정식":
            current_quantity = self.cart_items.get(item, [0, 0])[1]
            if current_quantity >= self.special_menu_stock["삼겹살 정식"]:
                QMessageBox.warning(self, "품절", "삼겹살 정식은 하루 최대 10개만 주문 가능합니다!")
                return

        if item in self.cart_items:
            self.cart_items[item][1] += 1
        else:
            self.cart_items[item] = [price, 1]
        self.updateCart()

    def placeOrder(self):
        order_summary = QTableWidget()
        order_summary.setColumnCount(3)
        order_summary.setHorizontalHeaderLabels(["메뉴", "수량", "가격"])
        order_summary.setRowCount(len(self.cart_items))

        total_price = 0
        order_details = []

        if self.current_table not in self.table_order_history:
            self.table_order_history[self.current_table] = []

        if "삼겹살 정식" in self.cart_items:
            price, quantity = self.cart_items["삼겹살 정식"]

            remaining_stock = self.special_menu_stock.get("삼겹살 정식", 10)  # 재고가 없으면 기본값 10

            if remaining_stock == 0:
                QMessageBox.warning(self, "품절", f"삼겹살 정식은 하루 최대 10개까지 주문 가능합니다!\n(현재 남은 수량: {remaining_stock}개)")
                return

            if quantity > remaining_stock:
                QMessageBox.warning(self, "품절", f"삼겹살 정식은 하루 최대 10개까지 주문 가능합니다!\n(현재 남은 수량: {remaining_stock}개)")
                return

            self.special_menu_stock["삼겹살 정식"] -= quantity

            print(f"✅ 삼겹살 정식 주문 완료! 남은 수량: {self.special_menu_stock['삼겹살 정식']}개")

        for row, (item, (price, quantity)) in enumerate(self.cart_items.items()):
            order_summary.setItem(row, 0, QTableWidgetItem(item))
            order_summary.setItem(row, 1, QTableWidgetItem(str(quantity)))
            order_summary.setItem(row, 2, QTableWidgetItem(f"{price * quantity}원"))
            total_price += price * quantity
            order_details.append(f"{item} x{quantity}개 ({price * quantity}원)")

        order_text = "\n".join(order_details)
        self.table_order_history[self.current_table].append(f"총액: {total_price}원\n{order_text}")

        save_order_to_db(self.current_table, item, quantity, price)
        self.save_order_to_file(self.current_table, self.cart_items, total_price)

        order_summary.resizeColumnsToContents()

        receipt_dialog = QDialog(self)
        receipt_dialog.setWindowTitle("🧾 주문 영수증")
        receipt_dialog.setFixedSize(400, 500)

        layout = QVBoxLayout()

        title_label = QLabel("🧾 주문 완료")
        title_label.setFont(QFont("Arial", 18, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)

        table_label = QLabel(f"테이블 번호: {self.current_table}")
        table_label.setFont(QFont("Arial", 14))
        table_label.setAlignment(Qt.AlignCenter)

        receipt_text = QTextEdit()
        receipt_text.setReadOnly(True)
        receipt_text.setFont(QFont("Arial", 12))
        receipt_text.setText("\n".join(order_details) + f"\n\n🛒 총 결제 금액: {total_price}원")

        receipt_text.setStyleSheet("background-color: #f8f8f8; padding: 10px; border-radius: 5px;")

        confirm_button = QPushButton("확인")
        confirm_button.setFont(QFont("Arial", 14, QFont.Bold))
        confirm_button.setStyleSheet("background-color: #4CAF50; color: white; padding: 10px; border-radius: 5px;")
        confirm_button.clicked.connect(receipt_dialog.accept)

        layout.addWidget(title_label)
        layout.addWidget(table_label)
        layout.addWidget(receipt_text)
        layout.addWidget(confirm_button)

        receipt_dialog.setLayout(layout)
        receipt_dialog.exec_()


        # 장바구니 초기화
        self.cart_items.clear()
        self.updateCart()

    def save_order_to_file(self, table_number, cart_items, total_price):
        order_data = {
            "table_number": table_number,
            "cart_items": cart_items,
            "total_price": total_price
        }

        self.ros_node.publish_order(order_data)

        try:
            with open("orders.json", "r", encoding="utf-8") as file:
                orders = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            orders = []

        orders.append(order_data)
    
        with open("orders.json", "w", encoding="utf-8") as file:
            json.dump(orders, file, ensure_ascii=False, indent=4)

    def updateCart(self):
        for i in reversed(range(self.cart.count())):
            self.cart.itemAt(i).widget().deleteLater()

        for item, (price, quantity) in self.cart_items.items():
            item_layout = QHBoxLayout()

            item_label = QLabel(f"{item} - {price}원")
            quantity_spinbox = QSpinBox()
            quantity_spinbox.setValue(quantity)
            quantity_spinbox.setMinimum(1)
            quantity_spinbox.valueChanged.connect(lambda value, name=item: self.changeCartQuantity(name, value))

            item_layout.addWidget(item_label)
            item_layout.addWidget(quantity_spinbox)

            container = QWidget()
            container.setLayout(item_layout)
            self.cart.addWidget(container)

    def changeCartQuantity(self, item, quantity):
        if item in self.special_menu_stock:
            current_quantity = self.cart_items[item][1]
            stock_available = self.special_menu_stock[item] + current_quantity
            if quantity > stock_available:
                QMessageBox.warning(self, "재고 부족", f"{item}은(는) 재고가 부족합니다. 최대 {stock_available}개까지 가능합니다.")
                return

            self.special_menu_stock[item] += current_quantity - quantity

        if quantity == 0:
            del self.cart_items[item]
        else:
            self.cart_items[item][1] = quantity
        self.updateCart()

    def showOrderHistory(self, table):
        if not self.table_order_history[table]:
            QMessageBox.information(self, "주문 내역", "주문 내역이 없습니다.")
            return

        # ✅ 테이블별 주문 내역을 가져와 표시
        history_data = "\n".join(self.table_order_history[table])

        # ✅ 새로운 주문 내역 다이얼로그 (영수증 스타일)
        history_dialog = QDialog(self)
        history_dialog.setWindowTitle(f"🧾 테이블 {table} 주문 내역")
        history_dialog.setFixedSize(350, 450)

        layout = QVBoxLayout()

        # ✅ 타이틀 (영수증 느낌)
        title_label = QLabel(f"🧾 테이블 {table} 주문 내역")
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: black;")
        title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(title_label)

        # ✅ 주문 내역 텍스트 박스 (스크롤 가능)
        receipt_text = QTextEdit()
        receipt_text.setReadOnly(True)
        receipt_text.setStyleSheet("font-size: 14px; font-family: 'Courier New'; background-color: #f8f8f8; border: 1px solid gray; padding: 10px;")

        receipt_text.setText(f"📅 날짜: {QDate.currentDate().toString('yyyy-MM-dd')}\n\n{history_data}\n\n감사합니다!")

        layout.addWidget(receipt_text)

        # ✅ 닫기 버튼
        close_button = QPushButton("닫기")
        close_button.setStyleSheet("background-color: #4CAF50; color: white; font-size: 14px; padding: 10px; border-radius: 5px;")
        close_button.clicked.connect(history_dialog.accept)
        layout.addWidget(close_button)

        history_dialog.setLayout(layout)
        history_dialog.exec_() # ✅ 다이얼로그 실행


    def clearLayout(self, layout):
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
def main():
    rclpy.init()  # ROS 초기화
    ros_node = OrderPublisher()  # ROS 퍼블리셔 노드 생성

    # ROS 노드를 별도 스레드에서 실행
    ros_thread = RosNodeThread(ros_node)
    ros_thread.start()

    app = QApplication(sys.argv)
    window = PCCafe(ros_node)  # ros_node를 PCCafe에 전달
    window.show()

    try:
        sys.exit(app.exec_())
    except KeyboardInterrupt:
        pass
    finally:
        ros_thread.stop() 

    sys.exit(app.exec_())


if __name__ == "__main__":
    main() 