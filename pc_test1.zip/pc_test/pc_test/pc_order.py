import sys
import json
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QPushButton, QVBoxLayout, QLabel, QGridLayout,
    QTabWidget, QHBoxLayout, QWidget, QGroupBox, QMessageBox, QSpinBox, QScrollArea, QFrame, QTableWidget, QTableWidgetItem
)
from PyQt5.QtCore import QTimer, QTime, QDate, Qt
from PyQt5.QtGui import QPixmap, QFont
from PyQt5.QtCore import QThread
from pc_test.database import save_order_to_db

class OrderPublisher(Node):
    def __init__(self):
        super().__init__('order_publisher')
        self.publisher = self.create_publisher(String, 'order_topic', 10)

    def publish_order(self, order_data):
        msg = String()
        msg.data = json.dumps(order_data, ensure_ascii=False)
        self.publisher.publish(msg)
        self.get_logger().info(f'Published order: {msg.data}')

class RosNodeThread(QThread):
    def __init__(self, ros_node):
        super().__init__()
        self.ros_node = ros_node

    def run(self):
        rclpy.spin(self.ros_node)  # ROS 노드 실행

    def stop(self):
        rclpy.shutdown()  # ROS 종료

class PCCafe(QMainWindow):
    def __init__(self, ros_node):
        super().__init__()
        self.ros_node = ros_node  # ROS 노드를 생성자에서 전달받아 저장
        self.setWindowTitle("PC방 관리 시스템")
        self.setGeometry(100, 100, 1200, 800)  # 넓은 창 크기 설정

        # 테이블 상태 관리
        self.tables = {i: None for i in range(1, 10)}
        self.table_order_history = {i: [] for i in range(1, 10)}  # 각 테이블의 주문 내역
        self.special_menu_stock = {"삼겹살 정식": 10}  # 한정판 재고
        self.cart_items = {}  # 장바구니: {메뉴 이름: [가격, 수량]}
        self.current_table = None  # 현재 선택된 테이블

        self.initUI()

    def initUI(self):
        self.main_layout = QVBoxLayout()

        # 상단 정보
        header_layout = QHBoxLayout()

        title_label = QLabel("PC방 관리 시스템")
        title_label.setFont(QFont("Arial", 24, QFont.Bold))
        title_label.setStyleSheet("color: white;")
        header_layout.addWidget(title_label, alignment=Qt.AlignLeft)

        date_label = QLabel(QDate.currentDate().toString("yyyy-MM-dd"))
        date_label.setFont(QFont("Arial", 18))
        date_label.setStyleSheet("color: white;")
        header_layout.addWidget(date_label, alignment=Qt.AlignRight)

        self.main_layout.addLayout(header_layout)

        # 테이블 선택 버튼
        table_layout = QGridLayout()
        table_layout.setSpacing(10)

        for i in range(1, 10):
            btn = QPushButton(f"테이블 {i}")
            btn.setFont(QFont("Arial", 18, QFont.Bold))
            btn.setStyleSheet("background-color: #87CEEB; color: black; border: 2px solid #1E90FF; border-radius: 10px; padding: 20px;")
            btn.clicked.connect(lambda _, table=i: self.selectTable(table))
            table_layout.addWidget(btn, (i-1)//3, (i-1)%3)

        table_layout.setContentsMargins(50, 20, 50, 50)  # 여백 추가
        self.main_layout.addLayout(table_layout)

        self.central_widget = QWidget()
        self.central_widget.setLayout(self.main_layout)
        self.central_widget.setStyleSheet("background-color: #4682B4;")
        self.setCentralWidget(self.central_widget)

    def selectTable(self, table):
        if self.tables[table] is not None:
            QMessageBox.warning(self, "이미 할당된 좌석", "이미 할당된 좌석입니다. 다른 좌석을 선택해주세요.")
            return

        self.current_table = table
        self.showTableScreen(table)

    def showTableScreen(self, table):
        self.clearLayout(self.main_layout)

        # 선택된 테이블 번호
        table_label = QLabel(f"선택된 테이블: {table}번")
        table_label.setFont(QFont("Arial", 18))
        table_label.setStyleSheet("color: white;")
        self.main_layout.addWidget(table_label)

        # 시간 선택 안내
        time_label = QLabel("몇 시간 동안 사용할지 선택하세요:")
        time_label.setFont(QFont("Arial", 16))
        time_label.setStyleSheet("color: white;")
        self.main_layout.addWidget(time_label)

        # 시간 선택 버튼
        time_layout = QGridLayout()
        time_layout.setSpacing(30)

        for i in range(1, 5):
            btn = QPushButton(f"{i}시간")
            btn.setFont(QFont("Arial", 18, QFont.Bold))
            btn.setStyleSheet("background-color: #87CEEB; color: black; border: 2px solid #1E90FF; border-radius: 10px; padding: 50px;")
            btn.clicked.connect(lambda _, hours=i: self.allocateTime(table, hours))
            time_layout.addWidget(btn, 0, i - 1)

        time_layout.setContentsMargins(50, 20, 50, 50)
        self.main_layout.addLayout(time_layout)

        # Clear overlapping background
        self.central_widget = QWidget()
        self.central_widget.setStyleSheet("background-color: #4682B4;")
        self.central_widget.setLayout(self.main_layout)
        self.setCentralWidget(self.central_widget)

    def allocateTime(self, table, hours):
        self.tables[table] = QTime.currentTime().addSecs(hours * 3600)
        QMessageBox.information(self, "시간 할당 완료", f"{hours}시간이 할당되었습니다.")
        self.showMenuScreen(table, hours)

    def showMenuScreen(self, table, hours):
        self.clearLayout(self.main_layout)

        # 상단 남은 시간 표시 및 홈 버튼
        header_layout = QHBoxLayout()

        self.timer_label = QLabel(f"남은 시간: {hours}:00")
        self.timer_label.setFont(QFont("Arial", 18))
        self.timer_label.setStyleSheet("color: white;")
        header_layout.addWidget(self.timer_label)

        home_btn = QPushButton("홈으로")
        home_btn.setFont(QFont("Arial", 14))
        home_btn.setStyleSheet("background-color: #FF6347; color: white; border: 2px solid #FF4500; border-radius: 10px;")
        home_btn.clicked.connect(self.initUI)
        header_layout.addWidget(home_btn)

        self.main_layout.addLayout(header_layout)

        # 탭 메뉴 구성
        tab_widget = QTabWidget()
        tab_widget.setStyleSheet("QTabBar::tab { background: #4682B4; color: white; padding: 10px; border-radius: 5px; } QTabBar::tab:selected { background: #1E90FF; font-weight: bold; }")

        # 라면 종류 탭
        ramen_tab = self.createMenuTab("라면 종류", ["불닭볶음면", "짜계치", "해장라면", "떡라면"], 3000)
        tab_widget.addTab(ramen_tab, "라면")

        # 간식 종류 탭
        snack_tab = self.createMenuTab("간식", ["치킨", "떡볶이", "소떡소떡", "감자튀김"], 2000)
        tab_widget.addTab(snack_tab, "간식")

        # 밥 종류 탭
        rice_tab = self.createMenuTab("밥 종류", ["김치볶음밥", "스팸볶음밥", "새우볶음밥"], 4000)
        tab_widget.addTab(rice_tab, "밥")

        # 음료수 탭
        drink_tab = self.createMenuTab("음료수", ["콜라", "사이다", "아이스티", "아이스커피", "물", "초코라떼"], 1500)
        tab_widget.addTab(drink_tab, "음료수")

        # 한정판 탭
        special_tab = self.createSpecialMenuTab("한정판", ["삼겹살 정식"], 3500)
        tab_widget.addTab(special_tab, "한정판")

        self.main_layout.addWidget(tab_widget)

        # 장바구니 및 주문 버튼
        cart_layout = QVBoxLayout()

        cart_label = QLabel("장바구니")
        cart_label.setFont(QFont("Arial", 18))
        cart_label.setStyleSheet("color: white;")
        cart_layout.addWidget(cart_label)

        self.cart = QVBoxLayout()
        cart_scroll = QScrollArea()
        cart_scroll_widget = QWidget()
        cart_scroll_widget.setLayout(self.cart)
        cart_scroll.setWidget(cart_scroll_widget)
        cart_scroll.setWidgetResizable(True)
        cart_scroll.setFixedHeight(250)
        cart_scroll.setStyleSheet("background-color: #F0F8FF; border: 1px solid #1E90FF; border-radius: 10px;")
        cart_layout.addWidget(cart_scroll)

        order_layout = QHBoxLayout()
        order_btn = QPushButton("주문")
        order_btn.setFont(QFont("Arial", 14))
        order_btn.setStyleSheet("background-color: #32CD32; color: white; border: 2px solid #228B22; border-radius: 10px;")
        order_btn.clicked.connect(self.placeOrder)
        order_layout.addWidget(order_btn)

        history_btn = QPushButton("주문 내역 확인")
        history_btn.setFont(QFont("Arial", 14))
        history_btn.setStyleSheet("background-color: #FFA500; color: white; border: 2px solid #FF8C00; border-radius: 10px;")
        history_btn.clicked.connect(lambda: self.showOrderHistory(self.current_table))
        order_layout.addWidget(history_btn)

        cart_layout.addLayout(order_layout)

        cart_widget_container = QWidget()
        cart_widget_container.setLayout(cart_layout)
        self.main_layout.addWidget(cart_widget_container)

        self.central_widget.setLayout(self.main_layout)

    def createMenuTab(self, category, items, price):
        tab_layout = QGridLayout()
        tab_layout.setSpacing(10)

        for row, item in enumerate(items):
            pixmap = QPixmap(100, 100)
            pixmap.fill(Qt.gray)
            image_label = QLabel()
            image_label.setPixmap(pixmap)
            image_label.setStyleSheet("border: 1px solid #1E90FF; border-radius: 10px;")

            item_label = QLabel(f"{item}\n{price}원")
            item_label.setFont(QFont("Arial", 12))
            item_label.setStyleSheet("color: white;")
            item_label.setAlignment(Qt.AlignCenter)

            add_btn = QPushButton("추가")
            add_btn.setFont(QFont("Arial", 12))
            add_btn.setStyleSheet("background-color: #87CEEB; color: black; border: 2px solid #1E90FF; border-radius: 10px;")
            add_btn.clicked.connect(lambda _, name=item, p=price: self.addToCart(name, p))

            item_container = QVBoxLayout()
            item_container.addWidget(image_label)
            item_container.addWidget(item_label)
            item_container.addWidget(add_btn)

            container = QWidget()
            container.setLayout(item_container)

            tab_layout.addWidget(container, row // 3, row % 3)

        tab_widget = QWidget()
        tab_widget.setLayout(tab_layout)
        return tab_widget

    def createSpecialMenuTab(self, category, items, prices):
        return self.createMenuTab(category, items, prices)

    def addToCart(self, item, price):

        if item == "삼겹살 정식":
            current_quantity = self.cart_items.get(item, [0, 0])[1]
            if current_quantity >= self.special_menu_stock["삼겹살 정식"]:
                QMessageBox.warning(self, "품절", "삼겹살 정식은 하루 최대 10개만 주문 가능합니다!")
                return
                 
        if item in self.cart_items:
            self.cart_items[item][1] += 1
        else:
            self.cart_items[item] = [price, 1]
        self.updateCart()

    def placeOrder(self):
        order_summary = QTableWidget()
        order_summary.setColumnCount(3)
        order_summary.setHorizontalHeaderLabels(["메뉴", "수량", "가격"])
        order_summary.setRowCount(len(self.cart_items))

        total_price = 0
        order_details = []

        if "삼겹살 정식" in self.cart_items:
            price, quantity = self.cart_items["삼겹살 정식"]
            if quantity > self.special_menu_stock["삼겹살 정식"]:
                QMessageBox.warning(self, "품절", "삼겹살 정식은 하루 최대 10개만 주문 가능합니다!")
                return

        for row, (item, (price, quantity)) in enumerate(self.cart_items.items()):
            order_summary.setItem(row, 0, QTableWidgetItem(item))
            order_summary.setItem(row, 1, QTableWidgetItem(str(quantity)))
            order_summary.setItem(row, 2, QTableWidgetItem(f"{price * quantity}원"))
            total_price += price * quantity
            order_details.append(f"{item} x{quantity}개 ({price * quantity}원)")

        if "삼겹살 정식" in self.cart_items:
            self.special_menu_stock["삼겹살 정식"] -= self.cart_items["삼겹살 정식"][1]

        order_text = "\n".join(order_details)
        self.table_order_history[self.current_table].append(f"총액: {total_price}원\n{order_text}")

        save_order_to_db(self.current_table, item, quantity, price)
        self.save_order_to_file(self.current_table, self.cart_items, total_price)


        order_summary.resizeColumnsToContents()
        QMessageBox.information(self, "주문 완료", f"총액: {total_price}원\n주문 내역은 아래와 같습니다.\n{order_text}")

        # 테이블 별로 주문 내역 저장
        if self.current_table is not None:
            self.table_order_history[self.current_table].append(f"총액: {total_price}원")

        # 장바구니 초기화
        self.cart_items.clear()
        self.updateCart()

    def save_order_to_file(self, table_number, cart_items, total_price):
        order_data = {
            "table_number": table_number,
            "cart_items": cart_items,
            "total_price": total_price
        }

        self.ros_node.publish_order(order_data)

        try:
            with open("orders.json", "r", encoding="utf-8") as file:
                orders = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            orders = []

        orders.append(order_data)
    
        with open("orders.json", "w", encoding="utf-8") as file:
            json.dump(orders, file, ensure_ascii=False, indent=4)

    def updateCart(self):
        for i in reversed(range(self.cart.count())):
            self.cart.itemAt(i).widget().deleteLater()

        for item, (price, quantity) in self.cart_items.items():
            item_layout = QHBoxLayout()

            item_label = QLabel(f"{item} - {price}원")
            quantity_spinbox = QSpinBox()
            quantity_spinbox.setValue(quantity)
            quantity_spinbox.setMinimum(1)
            quantity_spinbox.valueChanged.connect(lambda value, name=item: self.changeCartQuantity(name, value))

            item_layout.addWidget(item_label)
            item_layout.addWidget(quantity_spinbox)

            container = QWidget()
            container.setLayout(item_layout)
            self.cart.addWidget(container)

    def changeCartQuantity(self, item, quantity):
        if item in self.special_menu_stock:
            current_quantity = self.cart_items[item][1]
            stock_available = self.special_menu_stock[item] + current_quantity
            if quantity > stock_available:
                QMessageBox.warning(self, "재고 부족", f"{item}은(는) 재고가 부족합니다. 최대 {stock_available}개까지 가능합니다.")
                return

            self.special_menu_stock[item] += current_quantity - quantity

        if quantity == 0:
            del self.cart_items[item]
        else:
            self.cart_items[item][1] = quantity
        self.updateCart()

    def showOrderHistory(self, table):
        if not self.table_order_history[table]:
            QMessageBox.information(self, "주문 내역", "주문 내역이 없습니다.")
        else:
            history = "\n\n".join(self.table_order_history[table])
            QMessageBox.information(self, "주문 내역", f"테이블 {table} 주문 내역:\n{history}")

    def clearLayout(self, layout):
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
def main():
    rclpy.init()  # ROS 초기화
    ros_node = OrderPublisher()  # ROS 퍼블리셔 노드 생성

    # ROS 노드를 별도 스레드에서 실행
    ros_thread = RosNodeThread(ros_node)
    ros_thread.start()

    app = QApplication(sys.argv)
    window = PCCafe(ros_node)  # ros_node를 PCCafe에 전달
    window.show()

    try:
        sys.exit(app.exec_())
    except KeyboardInterrupt:
        pass
    finally:
        ros_thread.stop() 

    sys.exit(app.exec_())


if __name__ == "__main__":
    main() 