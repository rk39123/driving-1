import sys
import json
import rclpy
import mysql.connector
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import PoseStamped
from nav2_msgs.srv import SetInitialPose
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QGridLayout, QFrame,
    QPushButton, QDialog, QTabWidget, QDateEdit
)
from PyQt5.QtCore import Qt, QDate, QTimer
from PyQt5.QtGui import QPixmap
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

class SalesDataManager:
    def __init__(self):
        self.db_connection = mysql.connector.connect(
            host="localhost",
            user="pc_user",
            password="wns032715!",
            database="pc_db"
        )
        self.cursor = self.db_connection.cursor()
    
    def fetch_sales_data(self, date):
        query = """
            SELECT DATE_FORMAT(timestamp, '%Y-%m-%d'), SUM(price * quantity)
            FROM orders
            WHERE DATE_FORMAT(timestamp, '%Y-%m-%d') LIKE %s
            GROUP BY DATE_FORMAT(timestamp, '%Y-%m-%d');
        """
        self.cursor.execute(query, (date + '%',))
        return dict(self.cursor.fetchall())
    
    def fetch_top_selling_items(self, date):
        query = """
            SELECT menu_item, SUM(quantity)
            FROM orders
            WHERE DATE_FORMAT(timestamp, '%Y-%m-%d') = %s
            GROUP BY menu_item
            ORDER BY SUM(quantity) DESC;
        """
        self.cursor.execute(query, (date,))
        return dict(self.cursor.fetchall())

class ManagementUI(QDialog):
    def __init__(self, data_manager, parent=None):
        super().__init__(parent)
        self.data_manager = data_manager
        self.setWindowTitle("매장 관리 시스템")
        self.setGeometry(200, 200, 1000, 600)
        layout = QVBoxLayout()
        
        self.date_picker = QDateEdit()
        self.date_picker.setCalendarPopup(True)
        self.date_picker.setDate(QDate.currentDate())
        self.date_picker.dateChanged.connect(self.update_statistics)
        layout.addWidget(self.date_picker)
        
        self.tabs = QTabWidget()
        self.revenue_tab = QWidget()
        self.sales_tab = QWidget()
        self.tabs.addTab(self.revenue_tab, "📊 매출 현황")
        self.tabs.addTab(self.sales_tab, "🍽️ 인기 메뉴")
        layout.addWidget(self.tabs)
        self.setLayout(layout)
        
        self.init_revenue_tab()
        self.init_sales_tab()
        self.update_statistics()
    
    def init_revenue_tab(self):
        self.revenue_tab.layout = QVBoxLayout()
        self.revenue_canvas = FigureCanvas(plt.Figure())
        self.revenue_tab.layout.addWidget(self.revenue_canvas)
        self.revenue_tab.setLayout(self.revenue_tab.layout)
    
    def init_sales_tab(self):
        self.sales_tab.layout = QVBoxLayout()
        self.sales_canvas = FigureCanvas(plt.Figure())
        self.sales_tab.layout.addWidget(self.sales_canvas)
        self.sales_tab.setLayout(self.sales_tab.layout)
    
    def update_statistics(self):
        selected_date = self.date_picker.date().toString("yyyy-MM")
        daily_date = self.date_picker.date().toString("yyyy-MM-dd")
        sales_data = self.data_manager.fetch_sales_data(selected_date)
        top_selling_items = self.data_manager.fetch_top_selling_items(daily_date)
        self.update_revenue_chart(sales_data)
        self.update_sales_chart(top_selling_items)
    
    def update_revenue_chart(self, sales_data):
        self.revenue_canvas.figure.clear()
        ax = self.revenue_canvas.figure.add_subplot(111)
        if sales_data:
            dates, revenues = zip(*sorted(sales_data.items()))
            ax.plot(dates, revenues, marker="o", linestyle="-", color="#ff6699")
            ax.set_xlabel("날짜")
            ax.set_ylabel("매출 (원)")
            ax.set_title("매출 변화 추이")
        else:
            ax.text(0.5, 0.5, "데이터 없음", ha='center', va='center', fontsize=14)
        self.revenue_canvas.draw()
    
    def update_sales_chart(self, sales_data):
        self.sales_canvas.figure.clear()
        ax = self.sales_canvas.figure.add_subplot(111)
        if sales_data:
            items, quantities = zip(*sales_data.items())
            ax.barh(items, quantities, color='#66ccff')
            ax.set_xlabel("판매 개수")
            ax.set_title("인기 메뉴")
        else:
            ax.text(0.5, 0.5, "데이터 없음", ha='center', va='center', fontsize=14)
        self.sales_canvas.draw()

class KitchenDisplay(QWidget):
    def __init__(self, node):
        super().__init__()
        self.node = node
        self.data_manager = SalesDataManager()
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("주방 디스플레이")
        self.setGeometry(100, 100, 800, 600)
        layout = QVBoxLayout()
        
        self.manage_button = QPushButton("매장 관리")
        self.manage_button.clicked.connect(self.open_management_dialog)
        layout.addWidget(self.manage_button)
        
        self.setLayout(layout)
    
    def open_management_dialog(self):
        self.management_dialog = ManagementUI(self.data_manager, self)
        self.management_dialog.exec_()

def main():
    rclpy.init()
    kitchen_node = KitchenSubscriber()
    
    app = QApplication(sys.argv)
    kitchen_display = KitchenDisplay(kitchen_node)
    kitchen_display.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
