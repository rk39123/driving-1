class NODE(Node):
    def __init__(self):
        super().__init__()

        publisher = self.create_publish()